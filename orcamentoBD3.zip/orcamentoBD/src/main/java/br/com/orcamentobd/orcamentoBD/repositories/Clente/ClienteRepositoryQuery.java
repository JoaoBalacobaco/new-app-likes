package br.com.orcamentobd.orcamentoBD.repositories.Clente;

import br.com.orcamentobd.orcamentoBD.model.Cliente;
import br.com.orcamentobd.orcamentoBD.repositories.Filters.ClienteFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ClienteRepositoryQuery {
    public Page<Cliente> filtrar (ClienteFilter clienteFilter, Pageable pageable);
}
