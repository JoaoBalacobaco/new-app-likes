package br.com.orcamentobd.orcamentoBD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrcamentoBdApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrcamentoBdApplication.class, args);
	}

}
