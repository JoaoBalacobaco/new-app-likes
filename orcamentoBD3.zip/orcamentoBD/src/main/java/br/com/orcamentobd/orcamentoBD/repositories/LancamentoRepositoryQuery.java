package br.com.orcamentobd.orcamentoBD.repositories;

import br.com.orcamentobd.orcamentoBD.dto.LancamentoDto;
import br.com.orcamentobd.orcamentoBD.repositories.Filters.LancamentoFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface LancamentoRepositoryQuery {
    public Page<LancamentoDto> filtrar(LancamentoFilter lancamentoFilter, Pageable pageable);

}
