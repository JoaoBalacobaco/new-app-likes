package br.com.orcamentobd.orcamentoBD.repositories;

import br.com.orcamentobd.orcamentoBD.dto.ClienteDto;
import br.com.orcamentobd.orcamentoBD.repositories.Filters.ClienteFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ClienteRepositoryQuery{
    public Page<ClienteDto> filtrar(ClienteFilter clienteFilter, Pageable pageable);
}
